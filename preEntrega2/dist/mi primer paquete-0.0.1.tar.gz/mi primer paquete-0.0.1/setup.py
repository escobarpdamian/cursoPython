from setuptools import setup

setup(

    name="mi primer paquete",
    version="0.0.1",
    description="Este es mi primer paquete",
    author="Pablo Damian Escobar",
    author_email="escobarpdamian@gmail.com",
    packages=["primer_paquete"]
)